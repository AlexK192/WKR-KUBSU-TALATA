DROP TABLE "interactions";
DROP TABLE "users";
DROP TABLE "reviews";